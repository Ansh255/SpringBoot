package com.validate.dao;

import java.util.List;

import org.springframework.http.ResponseEntity;


import com.validate.model.LoginVO;



public interface RegisterDAO {

	 void insert(LoginVO loginvo) ;
		// TODO Au

	
	
	
}
